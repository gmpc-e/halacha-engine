package com.elad.halachatime.core.presets

import com.fasterxml.jackson.databind.DeserializationFeature
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import org.everit.json.schema.Schema
import org.everit.json.schema.ValidationException
import org.everit.json.schema.loader.SchemaLoader
import org.json.JSONObject
import org.json.JSONTokener
import java.io.InputStream
import java.net.URL
import java.nio.file.Files
import java.nio.file.Path
import java.util.jar.JarFile
import kotlin.io.path.extension

/**
 * Registry that loads board presets from:
 *  1) Classpath: /presets/*.json
 *  2) External dirs passed via -Dpreset.dir or PRESET_DIR (and legacy ./profiles)
 *
 * Validation:
 *  - Try v2 schema first (schemas/board-preset.schema.v2.json)
 *  - Fallback to v1 schema (schemas/board-preset.schema.json)
 *  - If both fail, skip the file with a clear multi-line error.
*/
class PresetRegistry(
private val externalDirs: List<Path> = emptyList()
) {
private val mapper = jacksonObjectMapper().apply {
findAndRegisterModules()
configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
}

// Load schemas like PresetValidateCli: v2 first, then v1
private val schemaV2: Schema? by lazy { loadSchemaOrNull("schemas/board-preset.schema.v2.json") }
private val schemaV1: Schema? by lazy { loadSchemaOrNull("schemas/board-preset.schema.json") }

private fun loadSchemaOrNull(name: String): Schema? =
javaClass.classLoader.getResourceAsStream(name)?.use { SchemaLoader.load(JSONObject(JSONTokener(it))) }

private data class Loaded(val fileId: String, val preset: BoardPreset)

private val merged: Map<String, BoardPreset> by lazy {
val found = mutableListOf<Loaded>()
// 1) Classpath /presets
found += loadFromClasspathDir("presets")
// 2) External (-Dpreset.dir / PRESET_DIR / ./profiles)
found += loadFromExternalDirs()

if (found.isEmpty()) {
System.err.println("[PresetRegistry] WARNING: no valid presets found (check -Dpreset.dir / classpath / schema).")
}

val out = linkedMapOf<String, BoardPreset>()
for (x in found) {
val k = x.preset.key
if (k.isBlank()) {
System.err.println("[PresetRegistry] SKIP ${x.fileId}: missing 'key'")
continue
}
out[k] = x.preset
}
out
}

fun listProfiles(): List<BoardPreset> = merged.values.sortedBy { it.displayName }
fun getProfile(key: String): BoardPreset? = merged[key]

// -------- loading helpers --------

private fun loadFromExternalDirs(): List<Loaded> {
val dirs = if (externalDirs.isNotEmpty()) externalDirs else defaultExternalDirs()
if (dirs.isEmpty()) return emptyList()

val out = mutableListOf<Loaded>()
dirs.forEach { dir ->
if (!Files.exists(dir) || !Files.isDirectory(dir)) return@forEach
Files.walk(dir).use { paths ->
paths.filter { Files.isRegularFile(it) && it.extension == "json" }
.forEach { path ->
val fileId = "fs:${path.fileName}"
val json = runCatching { Files.readString(path) }.getOrElse {
System.err.println("[PresetRegistry] SKIP $fileId → read error: ${it.message}")
return@forEach
}
loadOneJson(fileId, json)?.let(out::add)
}
}
}
return out
}

private fun loadFromClasspathDir(dir: String): List<Loaded> {
val cl = javaClass.classLoader
val roots: List<URL> = cl.getResources(dir).toList()
val out = mutableListOf<Loaded>()
for (root in roots) {
when (root.protocol) {
"file" -> {
val p = Path.of(root.toURI())
if (Files.isDirectory(p)) {
Files.list(p).use { stream ->
stream.filter { Files.isRegularFile(it) && it.extension == "json" }
.forEach { path ->
val fileId = "cp:${path.fileName}"
val json = runCatching { Files.readString(path) }.getOrElse {
System.err.println("[PresetRegistry] SKIP $fileId → read error: ${it.message}")
return@forEach
}
loadOneJson(fileId, json)?.let(out::add)
}
}
}
}
"jar" -> {
// Enumerate presets inside a jar
val spec = root.file // e.g. file:/.../app.jar!/presets
val bang = spec.indexOf("!")
if (bang > 0) {
val jarUrl = spec.substring(0, bang).removePrefix("file:")
JarFile(jarUrl).use { jar ->
val entries = jar.entries().toList()
.filter { !it.isDirectory && it.name.startsWith("$dir/") && it.name.endsWith(".json") }
for (e in entries) {
val fileId = "cp:${e.name.substringAfterLast('/')}"
val json = runCatching {
jar.getInputStream(e).use(InputStream::readBytes).toString(Charsets.UTF_8)
}.getOrElse {
System.err.println("[PresetRegistry] SKIP $fileId → read error: ${it.message}")
continue
}
loadOneJson(fileId, json)?.let(out::add)
}
}
}
}
}
}
return out
}

private fun loadOneJson(fileId: String, json: String): Loaded? {
// Try v2
val v2 = schemaV2
if (v2 != null) {
val ok = validate(json, v2)
if (ok == null) {
val preset: BoardPreset = runCatching { mapper.readValue(json) }.getOrElse { ex ->
System.err.println("[PresetRegistry] SKIP invalid preset: $fileId → JSON parse error: ${ex.message}")
return null
}
println("[PresetRegistry] OK $fileId key='${preset.key}', schema='v2', items=${preset.items.size}")
return Loaded(fileId, preset)
}
}
// Try v1
val v1 = schemaV1
if (v1 != null) {
val ok = validate(json, v1)
if (ok == null) {
val preset: BoardPreset = runCatching { mapper.readValue(json) }.getOrElse { ex ->
System.err.println("[PresetRegistry] SKIP invalid preset: $fileId → JSON parse error: ${ex.message}")
return null
}
// v1 files used `zmanim` field name historically; Models.kt maps to items via @JsonAlias
val count = preset.items.size
println("[PresetRegistry] OK $fileId key='${preset.key}', schema='v1', items=$count")
return Loaded(fileId, preset)
}
}

// Both schemas failed → print a compact multi-line error
val v2Err = schemaV2?.let { validate(json, it) }
val v1Err = schemaV1?.let { validate(json, it) }
when {
v2Err != null -> {
System.err.println("[PresetRegistry] SKIP invalid preset: $fileId → INVALID v2: ${summary(v2Err)}")
}
v1Err != null -> {
System.err.println("[PresetRegistry] SKIP invalid preset: $fileId → INVALID v1: ${summary(v1Err)}")
}
else -> {
System.err.println("[PresetRegistry] SKIP invalid preset: $fileId → no schema available on classpath")
}
}
return null
}

private fun validate(json: String, schema: Schema): ValidationException? =
try {
schema.validate(JSONObject(json))
null
} catch (ve: ValidationException) {
ve
}

private fun summary(ve: ValidationException): String {
val subs = if (ve.causingExceptions.isEmpty()) listOf(ve) else ve.causingExceptions
val head = "${subs.size} schema violation(s) found"
val details = subs.take(10).joinToString(separator = "\n") { sub ->
"  • ${sub.pointerToViolation.ifBlank { "#"} }: ${sub.message}"
}
return "$head\n$details"
}

private fun defaultExternalDirs(): List<Path> {
val cwd = Path.of("").toAbsolutePath().normalize()
val prop = System.getProperty("preset.dir")?.takeIf { it.isNotBlank() }?.let { Path.of(it) }
val env  = System.getenv("PRESET_DIR")?.takeIf { it.isNotBlank() }?.let { Path.of(it) }
val legacy = cwd.resolve("profiles") // legacy
return listOfNotNull(prop, env, legacy).filter { Files.exists(it) && Files.isDirectory(it) }
}

companion object {
fun fromDefaultLocations(): PresetRegistry {
// Let ctor discover: -Dpreset.dir / PRESET_DIR / ./profiles (if present)
return PresetRegistry(emptyList())
}
}
}