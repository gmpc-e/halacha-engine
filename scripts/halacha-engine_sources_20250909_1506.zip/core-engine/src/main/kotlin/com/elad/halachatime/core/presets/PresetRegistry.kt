package com.elad.halachatime.core.presets

import com.fasterxml.jackson.databind.DeserializationFeature
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import org.everit.json.schema.Schema
import org.everit.json.schema.loader.SchemaLoader
import org.json.JSONObject
import org.json.JSONTokener
import java.nio.file.Files
import java.nio.file.Path

class PresetRegistry(
    private val externalDirs: List<Path> = emptyList()
) {
    private val mapper = jacksonObjectMapper().apply {
        findAndRegisterModules()
        configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
    }

    private val schema: Schema by lazy {
        val candidates = listOf(
            "schemas/board-preset.schema.v2.json",
            "schemas/board-preset.schema.json"
        )
        val namedStream = candidates.asSequence()
            .map { name -> name to javaClass.classLoader.getResourceAsStream(name) }
            .firstOrNull { it.second != null }
            ?: error("Schema resource not found. Tried: $candidates")

        namedStream.second.use { stream ->
            val raw = JSONObject(JSONTokener(stream))
            SchemaLoader.load(raw)
        }
    }

    private val builtins: MutableMap<String, BoardPreset> = mutableMapOf(
        "GRA" to BoardPreset(
            key = "GRA",
            displayName = "Vilna Gaon (GRA)",
            sofZmanReference = SofZmanRef.GRA,
            alosMode = OffsetMode(OffsetType.DEGREES, 16.1),
            tzeitMode = OffsetMode(OffsetType.DEGREES, 7.083),
            misheyakirMinutes = 35
        ),
        "MGA" to BoardPreset(
            key = "MGA",
            displayName = "Magen Avraham (MGA)",
            sofZmanReference = SofZmanRef.MGA,
            alosMode = OffsetMode(OffsetType.FIXED_MINUTES, 72.0),
            tzeitMode = OffsetMode(OffsetType.FIXED_MINUTES, 72.0),
            misheyakirMinutes = 35
        )
    )

    private val merged: MutableMap<String, BoardPreset> by lazy {
        val map = builtins.toMutableMap()
        loadExternal().forEach { ext -> map[ext.key] = ext }
        map
    }

    fun listKeys(): List<String> = merged.keys.sorted()
    fun listProfiles(): List<BoardPreset> = merged.values.sortedBy { it.displayName }
    fun list(): List<BoardPreset> = listProfiles()
    fun all(): List<BoardPreset> = listProfiles()

    fun get(key: String): BoardPreset? = merged[key]
    fun getProfile(key: String): BoardPreset? = merged[key]

    fun getOrDefault(key: String, defaultKey: String = "GRA"): BoardPreset =
        merged[key] ?: merged[defaultKey] ?: error("Default preset '$defaultKey' not found")

    private fun loadExternal(): List<BoardPreset> {
        if (externalDirs.isEmpty()) return emptyList()
        val out = mutableListOf<BoardPreset>()

        externalDirs.forEach { dir ->
            if (!Files.exists(dir) || !Files.isDirectory(dir)) return@forEach
            Files.walk(dir).use { paths ->
                paths.filter { Files.isRegularFile(it) && it.toString().endsWith(".json") }
                    .forEach { path ->
                        runCatching {
                            val json = Files.readString(path)
                            if (!validate(json)) {
                                System.err.println("[PresetRegistry] Skipped invalid preset: ${path.fileName}")
                            } else {
                                val preset: BoardPreset = mapper.readValue(json)
                                out += preset
                            }
                        }.onFailure { ex ->
                            System.err.println("[PresetRegistry] Skipped ${path.fileName}: ${ex.message}")
                        }
                    }
            }
        }
        return out
    }

    private fun validate(json: String): Boolean = runCatching {
        val obj = JSONObject(json)
        schema.validate(obj)
    }.isSuccess

    companion object {
        fun fromDefaultLocations(): PresetRegistry {
            val cwd = Path.of("").toAbsolutePath().normalize()
            val profilesDir = cwd.resolve("profiles")
            val candidates = listOf(
                profilesDir,
                profilesDir.resolve("builtin"),
                profilesDir.resolve("community"),
            ).filter { Files.exists(it) && Files.isDirectory(it) }
            return PresetRegistry(externalDirs = candidates)
        }
    }
}
