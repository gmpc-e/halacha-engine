package com.elad.halacha.rest

import com.elad.halachatime.core.engine.ShaotZmaniyot
import com.elad.halachatime.core.engine.ZmanIntrospector
import com.elad.halachatime.core.engine.ZmanResolver
import com.elad.halachatime.core.model.Place
import com.elad.halachatime.core.model.ZmanRequest
import com.elad.halachatime.core.presets.BoardPreset
import com.elad.halachatime.core.presets.PresetRegistry
import com.fasterxml.jackson.databind.SerializationFeature
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule
import io.ktor.http.*
import io.ktor.serialization.jackson.jackson
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.plugins.contentnegotiation.ContentNegotiation
import io.ktor.server.plugins.statuspages.StatusPages
import io.ktor.server.plugins.statuspages.exception
import io.ktor.server.response.*
import io.ktor.server.routing.*
import java.nio.file.Files
import java.nio.file.Path
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import kotlin.reflect.KProperty1
import kotlin.reflect.full.declaredFunctions
import kotlin.reflect.full.memberProperties
import kotlin.reflect.jvm.isAccessible

fun main() {
    val port = System.getenv("PORT")?.toIntOrNull() ?: 8080
    val externalDirs = resolveExternalPresetDirs()
    val registry = if (externalDirs.isEmpty()) PresetRegistry.fromDefaultLocations() else PresetRegistry(externalDirs)

    embeddedServer(Netty, port = port) {
        install(StatusPages) {
            exception<Throwable> { call, cause ->
                call.respond(
                    HttpStatusCode.InternalServerError,
                    mapOf(
                        "error" to (cause.message ?: "internal error"),
                        "type" to (cause::class.simpleName ?: "Throwable")
                    )
                )
            }
        }
        install(ContentNegotiation) {
            jackson {
                registerModule(JavaTimeModule())
                disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
            }
        }

        routing {
            get("/health") { call.respond(mapOf("status" to "ok")) }

            // --- Profiles (tolerant) ---
            route("/profiles") {
                get {
                    val profiles: List<BoardPreset> = tryListProfiles(registry)
                    val payload = profiles.map { p -> mapOf("key" to p.key, "displayName" to p.displayName) }
                    call.respond(payload) // empty list if not discoverable
                }
                get("{key}") {
                    val key = call.parameters["key"].orEmpty()
                    val profile: BoardPreset? = getProfileCompat(registry, key)
                    if (profile == null) call.respond(HttpStatusCode.NotFound, mapOf("error" to "Profile '$key' not found"))
                    else call.respond(profile)
                }
            }

            // --- Zmanim (format=utc|local|both), versioned via ?scheme=v2 ---
            get("/zmanim") {
                val q = call.request.queryParameters
                val date = q["date"]?.let { LocalDate.parse(it) }
                    ?: return@get call.respond(HttpStatusCode.BadRequest, mapOf("error" to "date (yyyy-MM-dd) required"))

                // lat/lon optional (defaults to Jerusalem)
                val lat = q["lat"]?.toDoubleOrNull() ?: 31.778
                val lon = q["lon"]?.toDoubleOrNull() ?: 35.235
                val elev = q["elev"]?.toDoubleOrNull() ?: 800.0
                val tzId = q["tz"] ?: "Asia/Jerusalem"

                val presetKey = q["preset"] ?: "GRA"
                val format = (q["format"] ?: "both").lowercase()
                val scheme = (q["scheme"] ?: "").lowercase()
                val explain = q["explain"]?.toBoolean() ?: false
                val place = Place(q["name"] ?: "Custom", lat, lon, elev, tzId)

                // Compute with your existing engine (profile-aware)
                val res = ZmanResolver.compute(ZmanRequest(date, place, presetKey))

                // ---- V2 payload (DoD) ----
                if (scheme == "v2") {
                    val preset: BoardPreset? = getProfileCompat(registry, presetKey) // may be null
                    val items: List<ZmanItemV2> = buildItemsV2(preset, res, explain)

                    val shaped = when (format) {
                        "utc" -> items.map { it.copy(local = null) }
                        "local" -> items.map { it.copy(utc = null) }
                        else -> items
                    }

                    val payload = ZmanimResponseV2(
                        schemeVersion = "v2",
                        profileKey = presetKey, // echo requested key even if preset not found
                        meta = ZmanMeta(
                            date = date.toString(),
                            lat = lat, lon = lon, elevationM = elev, tz = tzId
                        ),
                        items = shaped
                    )
                    return@get call.respond(payload)
                }

                // ---- legacy/default payload (unchanged) ----
                val payload: Any = when (format) {
                    "utc" -> mapOf(
                        "preset" to res.preset, "place" to res.place, "date" to res.date,
                        "results" to res.results, "methodMap" to res.methodMap, "meta" to res.meta
                    )
                    "local" -> mapOf(
                        "preset" to res.preset, "place" to res.place, "date" to res.date,
                        "resultsLocal" to res.resultsLocal, "methodMap" to res.methodMap, "meta" to res.meta
                    )
                    else -> res
                }
                call.respond(payload)
            }

            // --- All CZC methods (format=utc|local|both) ---
            get("/zmanim/all-methods") {
                val q = call.request.queryParameters
                val date = q["date"]?.let { LocalDate.parse(it) }
                    ?: return@get call.respond(HttpStatusCode.BadRequest, mapOf("error" to "date (yyyy-MM-dd) required"))

                // lat/lon optional (defaults to Jerusalem)
                val lat = q["lat"]?.toDoubleOrNull() ?: 31.778
                val lon = q["lon"]?.toDoubleOrNull() ?: 35.235
                val elev = q["elev"]?.toDoubleOrNull() ?: 800.0
                val tzId = q["tz"] ?: "Asia/Jerusalem"
                val name = q["name"] ?: "Custom"
                val format = (q["format"] ?: "both").lowercase()

                val place = Place(name, lat, lon, elev, tzId)
                val raw = ZmanIntrospector.computeAll(date, place) // Map<Any, Date?>

                val zoneId = ZoneId.of(tzId)
                val fmt = DateTimeFormatter.ISO_OFFSET_DATE_TIME
                val utcMap = raw.mapKeys { (k, _) -> k.toString() }.mapValues { (_, d) -> d?.toInstant()?.toString() }
                val localMap = raw.mapKeys { (k, _) -> k.toString() }.mapValues { (_, d) -> d?.toInstant()?.atZone(zoneId)?.format(fmt) }

                val payload = when (format) {
                    "utc" -> mapOf(
                        "date" to date.toString(),
                        "place" to mapOf("name" to name, "lat" to lat, "lon" to lon, "elevationMeters" to elev, "timeZoneId" to tzId),
                        "count" to utcMap.size,
                        "methods" to utcMap,
                        "meta" to mapOf("format" to "utc", "engine" to "ComplexZmanimCalendar")
                    )
                    "local" -> mapOf(
                        "date" to date.toString(),
                        "place" to mapOf("name" to name, "lat" to lat, "lon" to lon, "elevationMeters" to elev, "timeZoneId" to tzId),
                        "count" to localMap.size,
                        "methods" to localMap,
                        "meta" to mapOf("format" to "local", "engine" to "ComplexZmanimCalendar")
                    )
                    else -> mapOf(
                        "date" to date.toString(),
                        "place" to mapOf("name" to name, "lat" to lat, "lon" to lon, "elevationMeters" to elev, "timeZoneId" to tzId),
                        "count" to localMap.size,
                        "methodsUtc" to utcMap,
                        "methodsLocal" to localMap,
                        "meta" to mapOf("format" to "both", "engine" to "ComplexZmanimCalendar")
                    )
                }
                call.respond(payload)
            }

            get("/debug/presets") {
                val fromEnv = System.getenv("PRESET_DIR")
                val fromProp = System.getProperty("preset.dir")
                val dir = fromProp ?: fromEnv
                val files = dir?.let { java.io.File(it).listFiles { f -> f.isFile && f.name.endsWith(".json") } }?.map { it.name } ?: emptyList()
                // Try to list profiles via reflection; if it throws, return the error
                val registryInfo = runCatching {
                    val reg = if (dir.isNullOrBlank()) PresetRegistry.fromDefaultLocations() else PresetRegistry(listOf(java.nio.file.Path.of(dir)))
                    val method = PresetRegistry::class.declaredFunctions.firstOrNull { it.name in setOf("listProfiles","list","all") && it.parameters.size == 1 }
                    method?.isAccessible = true
                    val listed = method?.call(reg) as? List<BoardPreset> ?: emptyList()
                    mapOf("count" to listed.size, "keys" to listed.map { it.key })
                }.fold(onSuccess = { it }, onFailure = { ex ->
                    mapOf("error" to (ex.message ?: ex::class.simpleName.orEmpty()))
                })
                call.respond(
                    mapOf(
                        "env_PRESET_DIR" to fromEnv,
                        "prop_preset.dir" to fromProp,
                        "dirExists" to (dir?.let { java.io.File(it).exists() } ?: false),
                        "jsonFiles" to files,
                        "registry" to registryInfo
                    )
                )
            }


            // --- Sha'ot/Dakot Zmaniyot ---
            get("/zmanim/shaot") {
                val q = call.request.queryParameters
                val date = q["date"]?.let { LocalDate.parse(it) }
                    ?: return@get call.respond(HttpStatusCode.BadRequest, mapOf("error" to "date (yyyy-MM-dd) required"))

                // lat/lon optional (defaults to Jerusalem)
                val lat = q["lat"]?.toDoubleOrNull() ?: 31.778
                val lon = q["lon"]?.toDoubleOrNull() ?: 35.235
                val elev = q["elev"]?.toDoubleOrNull() ?: 800.0
                val tzId = q["tz"] ?: "Asia/Jerusalem"
                val alosDeg = q["alosDeg"]?.toDoubleOrNull() ?: 16.1
                val tzaisDeg = q["tzaisDeg"]?.toDoubleOrNull() ?: 8.5
                val name = q["name"] ?: "Custom"

                val place = Place(name, lat, lon, elev, tzId)
                val gra = ShaotZmaniyot.compute(date, place, ShaotZmaniyot.Mode.GRA)
                val mga = ShaotZmaniyot.compute(date, place, ShaotZmaniyot.Mode.MGA, alosDeg, tzaisDeg)

                fun pretty(ms: Long) = if (ms <= 0) null else {
                    val minutes = ms / 60000.0
                    mapOf(
                        "millis" to ms,
                        "minutes" to "%.3f".format(minutes),
                        "hh:mm:ss" to String.format(
                            "%02d:%02d:%02d",
                            (ms / 3600000),
                            (ms % 3600000) / 60000,
                            (ms % 60000) / 1000
                        )
                    )
                }

                call.respond(
                    mapOf(
                        "date" to date.toString(),
                        "place" to mapOf("name" to name, "lat" to lat, "lon" to lon, "elevationMeters" to elev, "timeZoneId" to tzId),
                        "GRA" to mapOf("shaahZmanit" to pretty(gra.shaahMillis), "dakaZmanit" to pretty(gra.dakaMillis), "meta" to gra.meta),
                        "MGA" to mapOf("shaahZmanit" to pretty(mga.shaahMillis), "dakaZmanit" to pretty(mga.dakaMillis), "meta" to (mga.meta + mapOf("alosDeg" to alosDeg, "tzaisDeg" to tzaisDeg)))
                    )
                )
            }
        }
    }.start(wait = true)
}

/* ---------- V2 response models ---------- */

data class ZmanimResponseV2(
    val schemeVersion: String,
    val profileKey: String,
    val meta: ZmanMeta,
    val items: List<ZmanItemV2>
)

data class ZmanMeta(
    val date: String,
    val lat: Double,
    val lon: Double,
    val elevationM: Double,
    val tz: String
)

data class ZmanItemV2(
    val id: String,
    val label: Map<String, String>?,
    val utc: String?,
    val local: String?,
    val resolver: Any? = null,          // echoed only when explain=true (preset resolver object)
    val kosherJavaMethod: String? = null // echoed only when explain=true (preset or resolved methodMap)
)

/* ---------- Helpers ---------- */

private fun resolveExternalPresetDirs(): List<Path> {
    val fromEnv = System.getenv("PRESET_DIR")?.takeIf { it.isNotBlank() }?.let { Path.of(it) }
    val fromProp = System.getProperty("preset.dir")?.takeIf { it.isNotBlank() }?.let { Path.of(it) }
    return listOfNotNull(fromEnv, fromProp).filter { Files.exists(it) }
}

// Return [] instead of throwing if registry does not have a list method
private fun tryListProfiles(registry: PresetRegistry): List<BoardPreset> {
    val f = PresetRegistry::class.declaredFunctions.firstOrNull {
        it.name in setOf("listProfiles", "list", "all") && it.parameters.size == 1
    } ?: return emptyList()
    f.isAccessible = true
    @Suppress("UNCHECKED_CAST")
    return runCatching { f.call(registry) as List<BoardPreset> }.getOrElse { emptyList() }
}

private fun getProfileCompat(registry: PresetRegistry, key: String): BoardPreset? {
    val f = PresetRegistry::class.declaredFunctions.firstOrNull {
        it.name in setOf("getProfile", "get") && it.parameters.size == 2
    } ?: return null
    f.isAccessible = true
    @Suppress("UNCHECKED_CAST")
    return runCatching { f.call(registry, key) as BoardPreset? }.getOrNull()
}

// Build v2 items using preset.zmanim[*] if present; else fall back to engine maps.
// Also: normalize ANY map keys via toString() to avoid ClassCastException on enum/objects.
private fun buildItemsV2(
    preset: BoardPreset?,   // may be null
    res: Any,
    explain: Boolean
): List<ZmanItemV2> {
    val resultsRaw      = getMapAny(res, "results")       // Map<*, *>
    val resultsLocalRaw = getMapAny(res, "resultsLocal")  // Map<*, *>
    val methodMapRaw    = getMapAny(res, "methodMap")     // Map<*, *>

    val results      = toStringKeyed(resultsRaw)
    val resultsLocal = toStringKeyed(resultsLocalRaw)
    val methodMap    = toStringKeyed(methodMapRaw)

    val presetZmanim = preset?.let { getList(it, "zmanim") } // List<Any>?
    if (presetZmanim != null) {
        return presetZmanim.map { z ->
            val id    = getString(z, "id") ?: ""
            val label = getMap(z, "label") as? Map<String, String>
            val utc   = results[id]?.toString()
            val local = resultsLocal[id]?.toString()
            val methodNameFromEngine = methodMap[id]?.toString()

            val resolverEcho = if (explain) getAny(z, "resolver") else null
            val kjMethodPref = if (explain) (getString(z, "kosherJavaMethod") ?: methodNameFromEngine) else null

            ZmanItemV2(
                id = id,
                label = label,
                utc = utc,
                local = local,
                resolver = resolverEcho,
                kosherJavaMethod = kjMethodPref
            )
        }
    }

    // Fallback: emit whatever the engine produced (preserve stable id ordering)
    val ids = (results.keys + resultsLocal.keys + methodMap.keys).toSortedSet()
    return ids.map { id ->
        val utc   = results[id]?.toString()
        val local = resultsLocal[id]?.toString()
        val kj    = if (explain) methodMap[id]?.toString() else null
        ZmanItemV2(id = id, label = null, utc = utc, local = local, resolver = null, kosherJavaMethod = kj)
    }
}

private fun getAny(instance: Any, name: String): Any? =
    instance::class.memberProperties.firstOrNull { it.name == name }?.let { (it as KProperty1<Any, *>).get(instance) }

private fun getString(instance: Any, name: String): String? = (getAny(instance, name) as? String)

@Suppress("UNCHECKED_CAST")
private fun getMap(instance: Any, name: String): Map<String, Any?> =
    (getAny(instance, name) as? Map<String, Any?>) ?: emptyMap()

@Suppress("UNCHECKED_CAST")
private fun getList(instance: Any, name: String): List<Any>? =
    getAny(instance, name) as? List<Any>

@Suppress("UNCHECKED_CAST")
private fun getMapAny(instance: Any, name: String): Map<Any?, Any?> =
    (getAny(instance, name) as? Map<Any?, Any?>) ?: emptyMap()

private fun toStringKeyed(src: Map<Any?, Any?>): Map<String, Any?> =
    if (src.isEmpty()) emptyMap()
    else buildMap(src.size) {
        for ((k, v) in src) put(k?.toString() ?: "null", v)
    }
