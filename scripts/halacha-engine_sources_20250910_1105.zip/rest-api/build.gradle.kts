plugins {
    kotlin("jvm")
    application
}

repositories {
    mavenCentral()
}

dependencies {
    implementation(project(":core-engine"))

    implementation("io.ktor:ktor-server-netty:2.3.12")
    implementation("io.ktor:ktor-server-content-negotiation:2.3.12")
    implementation("io.ktor:ktor-serialization-jackson:2.3.12")
    implementation("ch.qos.logback:logback-classic:1.5.6")
    implementation("androidx.compose.ui:ui-desktop:1.7.0")

    testImplementation(kotlin("test"))
    testImplementation("org.junit.jupiter:junit-jupiter:5.10.3")
    testImplementation("io.ktor:ktor-server-test-host:2.3.12")
}

application {
    mainClass.set("com.elad.halacha.rest.ServerKt")
}

tasks.test {
    useJUnitPlatform()
}
