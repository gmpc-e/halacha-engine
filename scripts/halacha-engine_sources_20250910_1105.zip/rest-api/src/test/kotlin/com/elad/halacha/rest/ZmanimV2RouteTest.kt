package com.elad.halacha.rest

import androidx.compose.ui.window.application
import com.elad.halachatime.core.presets.PresetRegistry
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import com.fasterxml.jackson.module.kotlin.readValue
import io.ktor.client.request.get
import io.ktor.client.statement.bodyAsText
import io.ktor.http.HttpStatusCode
import io.ktor.server.testing.testApplication
import org.junit.jupiter.api.Assertions
import org.junit.jupiter.api.Test

class ZmanimV2RouteTest {
    private val mapper = jacksonObjectMapper().findAndRegisterModules()

    @Test
    fun `v2 returns preset-shaped items and kosherJavaMethod when explain=true`() = testApplication {
        application { halachaModule(PresetRegistry.Companion.fromDefaultLocations()) }

        val q = listOf(
            "date=2025-09-09",
            "lat=32.153",
            "lon=34.893",
            "elev=60",
            "tz=Asia/Jerusalem",
            "scheme=v2",
            "explain=true",
            "preset=GRA" // any v2 profile with items
        ).joinToString("&")

        val r = client.get("/zmanim?$q")
        Assertions.assertEquals(HttpStatusCode.OK, r.status)

        val body: Map<String, Any?> = mapper.readValue(r.bodyAsText())
        Assertions.assertEquals("v2", body["schemeVersion"])

        @Suppress("UNCHECKED_CAST")
        val items = body["items"] as List<Map<String, Any?>>
        Assertions.assertTrue(items.isNotEmpty(), "No items returned for v2 response")

        // every item has kosherJavaMethod (explain=true)
        Assertions.assertTrue(items.all { it["kosherJavaMethod"] != null })

        // shape respects format=local
        val rLocal = client.get("/zmanim?$q&format=local")
        val bLocal: Map<String, Any?> = mapper.readValue(rLocal.bodyAsText())
        @Suppress("UNCHECKED_CAST")
        val itemsLocal = bLocal["items"] as List<Map<String, Any?>>
        Assertions.assertTrue(itemsLocal.all { it["utc"] == null && it["local"] != null })
    }

    @Test
    fun `v2 fail-fast for missing or unknown preset`() = testApplication {
        application { halachaModule(PresetRegistry.Companion.fromDefaultLocations()) }

        val base = "date=2025-09-09&scheme=v2"

        // unknown
        val a = client.get("/zmanim?$base&preset=__NOPE__")
        Assertions.assertEquals(HttpStatusCode.BadRequest, a.status)

        // empty items (if such a preset existed, simulate by asking a name you don’t ship)
        // We assert error contract rather than status here.
        val b = client.get("/zmanim?$base&preset=MGA") // only if MGA is not v2; otherwise skip/remove
        if (b.status != HttpStatusCode.OK) {
            val err: Map<String, Any?> = mapper.readValue(b.bodyAsText())
            Assertions.assertTrue(err.containsKey("error"))
        }
    }
}