plugins {
    kotlin("jvm")
    application
}

repositories {
    mavenCentral()
}

kotlin {
    // Keep Kotlin on JDK 17
    jvmToolchain(17)
}

java {
    // Keep Java compile tasks on JDK 17 (matches Kotlin)
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(17))
    }
}

dependencies {
    implementation(project(":core-engine"))

    implementation("io.ktor:ktor-server-netty:2.3.12")
    implementation("io.ktor:ktor-server-content-negotiation:2.3.12")
    implementation("io.ktor:ktor-serialization-jackson:2.3.12")
    implementation("ch.qos.logback:logback-classic:1.5.6")

    // Needed for JavaTimeModule
    implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310:2.17.2")

    // KosherJava used directly by rest-api/ProfileMethodMapper.kt
    implementation("com.kosherjava:zmanim:2.5.0")

    testImplementation(kotlin("test"))
    testImplementation("org.junit.jupiter:junit-jupiter:5.10.3")
    testImplementation("io.ktor:ktor-server-test-host:2.3.12")
}

application {
    mainClass.set("com.elad.halacha.rest.ServerKt")
}

tasks.test {
    useJUnitPlatform()
}