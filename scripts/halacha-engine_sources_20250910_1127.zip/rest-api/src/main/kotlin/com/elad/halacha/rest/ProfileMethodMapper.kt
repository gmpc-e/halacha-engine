package com.elad.halacha.rest

import com.kosherjava.zmanim.ComplexZmanimCalendar
import com.kosherjava.zmanim.ZmanimCalendar
import java.util.Date
import kotlin.math.abs

/**
 * Profile-aware mapper from a preset resolver (any shape that exposes type/method/value)
 * to a concrete call on ComplexZmanimCalendar / ZmanimCalendar.
 *
 * This version is reflection-tolerant to avoid compile coupling to specific resolver classes.
 * Expected readable properties on [resolver]:
 *   - String  type   : "FORMULA" | "DEGREES" | "MINUTES"   (case-insensitive)
 *   - String  method : method family for DEGREES / MINUTES (e.g., "TZAIS_GEONIM", "ALOS")
 *   - Double  value  : degrees for DEGREES
 *   - Int     value  : minutes for MINUTES
 *   - String  value  : formula id for FORMULA (e.g., "GRA_SHEMA")
 */
object ProfileMethodMapper {

    /** Resolve a single preset resolver into a Date (UTC instant in Java Date). */
    @JvmStatic
    fun resolve(resolver: Any?, czc: ComplexZmanimCalendar, zc: ZmanimCalendar): Date? {
        if (resolver == null) return null

        val type = readString(resolver, "type")?.uppercase()
            ?: resolver::class.simpleName?.uppercase()

        return when (type) {
            "FORMULA" -> {
                val value = readString(resolver, "value") ?: return null
                resolveFormula(value.uppercase(), czc, zc)
            }
            "DEGREES" -> {
                val method = (readString(resolver, "method") ?: readString(resolver, "mode") ?: "").uppercase()
                val deg = readDouble(resolver, "value") ?: return null
                resolveDegrees(method, deg, czc)
            }
            "MINUTES" -> {
                val method = (readString(resolver, "method") ?: readString(resolver, "mode") ?: "").uppercase()
                val minutes = readInt(resolver, "value") ?: readDouble(resolver, "value")?.toInt() ?: return null
                resolveMinutes(method, minutes, czc)
            }
            else -> null
        }
    }

    /* ---------------- FORMULA ---------------- */

    private fun resolveFormula(value: String, czc: ComplexZmanimCalendar, zc: ZmanimCalendar): Date? = when (value) {
        // GRA core
        "GRA_SHEMA"        -> callDate(czc, "getSofZmanShmaGRA")
        "GRA_TEFILLA"      -> callDate(czc, "getSofZmanTfilaGRA")

        // MGA core + 19.8° variant
        "MGA_SHEMA"        -> callDate(czc, "getSofZmanShmaMGA")
        "MGA_SHEMA_19P8D"  -> callDate(czc, "getSofZmanShmaMGA19Point8Degrees")
        "MGA_TEFILLA_19P8D"-> callDate(czc, "getSofZmanTfilaMGA19Point8Degrees")

        // Chatzos / Mincha / Plag (GRA)
        "CHATZOS"                -> callDate(czc, "getChatzos") ?: callDate(czc, "getChatzosAsHalfDay")
        "MINCHA_GEDOLA_30M"      -> callDate(czc, "getMinchaGedola30Minutes")
        "MINCHA_KETANA_GRA"      -> callDate(czc, "getMinchaKetana")
        "PLAG_GRA"               -> callDate(czc, "getPlagHamincha")

        // Explicit PLAG flavors (per boards you asked to support)
        "PLAG_AHAVAT_SHALOM"           -> callDate(czc, "getPlagAhavatShalom") ?: callDate(czc, "plagAhavatShalom")
        "PLAG_ALOS16P1_TO_TZAIS_7P083" -> callDate(czc, "getPlagAlos16Point1ToTzaisGeonim7Point083Degrees")
        "PLAG_ATERET_TORAH"            -> callDate(czc, "getPlagHaminchaAteretTorah")
        "PLAG_16P1D"                   -> callDate(czc, "getPlagHamincha16Point1Degrees")
        "PLAG_18D"                     -> callDate(czc, "getPlagHamincha18Degrees")
        "PLAG_19P8D"                   -> callDate(czc, "getPlagHamincha19Point8Degrees")
        "PLAG_26D"                     -> callDate(czc, "getPlagHamincha26Degrees")

        // Sunrise / Sunset flavors
        "SEA_LEVEL_SUNRISE"            -> callDate(czc, "getSeaLevelSunrise") ?: callDate(zc, "getSunrise")
        "SEA_LEVEL_SUNSET"             -> callDate(czc, "getSeaLevelSunset")  ?: callDate(zc, "getSunset")
        "ELEVATION_ADJUSTED_SUNRISE"   -> callDate(czc, "getElevationAdjustedSunrise")
        "ELEVATION_ADJUSTED_SUNSET"    -> callDate(czc, "getElevationAdjustedSunset")

        else -> null
    }

    /* ---------------- DEGREES ---------------- */

    private fun resolveDegrees(method: String, deg: Double, czc: ComplexZmanimCalendar): Date? = when (method) {
        "ALOS" -> when {
            close(deg, 16.1) -> callDate(czc, "getAlos16Point1Degrees")
            close(deg, 19.8) -> callDate(czc, "getAlos19Point8Degrees")
            close(deg, 18.0) -> callDate(czc, "getAlos18Degrees")
            close(deg, 26.0) -> callDate(czc, "getAlos26Degrees")
            else             -> null
        }
        "MISHEYAKIR" -> when {
            close(deg, 11.5) -> callDate(czc, "getMisheyakir11Point5Degrees")
            close(deg, 10.2) -> callDate(czc, "getMisheyakir10Point2Degrees")
            else             -> null
        }
        "TZAIS_GEONIM" -> when {
            close(deg, 4.8)   || close(deg, 4.9)   -> callDate(czc, "getTzaisGeonim4Point8Degrees")
            close(deg, 6.45)                       -> callDate(czc, "getTzaisGeonim6Point45Degrees")
            close(deg, 7.083) || close(deg, 7.084) -> callDate(czc, "getTzaisGeonim7Point083Degrees")
            close(deg, 8.5)                        -> callDate(czc, "getTzaisGeonim8Point5Degrees")
            close(deg, 18.0)                       -> callDate(czc, "getTzais18Degrees")
            close(deg, 19.8)                       -> callDate(czc, "getTzais19Point8Degrees")
            close(deg, 26.0)                       -> callDate(czc, "getTzais26Degrees")
            else                                   -> null
        }
        else -> null
    }

    /* ---------------- MINUTES ---------------- */

    private fun resolveMinutes(method: String, minutes: Int, czc: ComplexZmanimCalendar): Date? = when (method) {
        // Rabbeinu Tam tzais in fixed minutes (e.g., 72)
        "TZAIS_FIXED_MINUTES" -> seaLevelSunset(czc)?.plusMinutes(minutes)

        // Symmetric fixed-minute alos (if any board uses it)
        "ALOS_FIXED_MINUTES"  -> seaLevelSunrise(czc)?.minusMinutes(minutes)

        else -> null
    }

    /* ---------------- Helpers ---------------- */

    private fun close(a: Double, b: Double, eps: Double = 0.02): Boolean = abs(a - b) <= eps

    private fun seaLevelSunrise(czc: ComplexZmanimCalendar): Date? =
        callDate(czc, "getSeaLevelSunrise") ?: callDate(czc, "getSunrise")

    private fun seaLevelSunset(czc: ComplexZmanimCalendar): Date? =
        callDate(czc, "getSeaLevelSunset") ?: callDate(czc, "getSunset")

    private fun Date.plusMinutes(min: Int): Date = Date(this.time + min * 60_000L)
    private fun Date.minusMinutes(min: Int): Date = Date(this.time - min * 60_000L)

    private fun callDate(target: Any, method: String): Date? =
        runCatching { target::class.java.getMethod(method).invoke(target) as? Date }.getOrNull()

    /* Reflection readers (tolerant to different resolver DTO shapes) */

    private fun readString(instance: Any, name: String): String? =
        runCatching { instance.javaClass.getMethod("get${name.capitalizeUS()}").invoke(instance) as? String }
            .getOrNull()
            ?: runCatching { instance.javaClass.getDeclaredField(name).apply { isAccessible = true }.get(instance) as? String }
                .getOrNull()

    private fun readDouble(instance: Any, name: String): Double? =
        (runCatching { instance.javaClass.getMethod("get${name.capitalizeUS()}").invoke(instance) as? Number }.getOrNull()
            ?: runCatching { instance.javaClass.getDeclaredField(name).apply { isAccessible = true }.get(instance) as? Number }.getOrNull())
            ?.toDouble()

    private fun readInt(instance: Any, name: String): Int? =
        (runCatching { instance.javaClass.getMethod("get${name.capitalizeUS()}").invoke(instance) as? Number }.getOrNull()
            ?: runCatching { instance.javaClass.getDeclaredField(name).apply { isAccessible = true }.get(instance) as? Number }.getOrNull())
            ?.toInt()

    private fun String.capitalizeUS(): String =
        replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
}