plugins {
    kotlin("jvm")
}

repositories {
    mavenCentral()
}

kotlin {
    // Force Kotlin to use a JDK 17 toolchain
    jvmToolchain(17)
}

java {
    // Force Java compile tasks to use JDK 17 too
    toolchain {
        languageVersion.set(JavaLanguageVersion.of(17))
    }
}

dependencies {
    // JSON
    implementation("com.fasterxml.jackson.core:jackson-databind:2.17.2")
    implementation("com.fasterxml.jackson.module:jackson-module-kotlin:2.17.2")

    // KosherJava Zmanim
    implementation("com.kosherjava:zmanim:2.5.0")

    // JSON Schema validation
    implementation("com.github.erosb:everit-json-schema:1.14.6")
    implementation("org.json:json:20240303")

    // Tests
    testImplementation(kotlin("test"))
    testImplementation("org.junit.jupiter:junit-jupiter:5.10.3")
}

tasks.test {
    useJUnitPlatform()
}

// ---- CLI tools (optional helper) ----
tasks.register<JavaExec>("validatePresets") {
    group = "verification"
    description = "Validate board preset JSONs against the v2 schema"
    classpath = sourceSets["main"].runtimeClasspath
    mainClass.set("com.elad.halachatime.core.presets.PresetValidateCli")
    jvmArgs(
        "-Dpreset.dir=" + (
                System.getProperty("preset.dir")
                    ?: System.getenv("PRESET_DIR")
                    ?: "${project.projectDir}/src/main/resources/presets"
                )
    )
}

tasks.named("check") { dependsOn("validatePresets") }