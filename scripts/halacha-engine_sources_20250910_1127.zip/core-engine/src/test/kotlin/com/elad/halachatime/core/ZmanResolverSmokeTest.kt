package com.elad.halachatime.core

import com.elad.halachatime.core.engine.ZmanResolver
import com.elad.halachatime.core.model.Place
import com.elad.halachatime.core.model.ZmanRequest
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test
import java.time.LocalDate

class ZmanResolverSmokeTest {

    @Test
    fun `compute returns core keys for GRA`() {
        val date = LocalDate.of(2025, 9, 9)
        val place = Place("Jerusalem", 31.778, 35.235, 800.0, "Asia/Jerusalem")

        val res = ZmanResolver.compute(ZmanRequest(date, place, "GRA"))

        // engine-result is a data class; use reflection helpers indirectly via maps in your own API
        val results = res.results
        assertTrue(results.isNotEmpty(), "Results should not be empty")

        // a few well-known ids from your engine
        assertTrue(results.containsKey(com.elad.halachatime.core.engine.ZmanMethodKey.SHEMA_END))
        assertTrue(results.containsKey(com.elad.halachatime.core.engine.ZmanMethodKey.TEFILLAH_END))

        // also methodMap should have something
        val methodMap = res.methodMap
        assertNotNull(methodMap["SHEMA_END"])
    }
}