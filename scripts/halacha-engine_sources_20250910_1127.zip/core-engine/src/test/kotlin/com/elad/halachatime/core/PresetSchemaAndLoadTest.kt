package com.elad.halachatime.core

import com.elad.halachatime.core.presets.PresetRegistry
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Assertions.assertNotNull
import org.junit.jupiter.api.Test

class PresetSchemaAndLoadTest {

    @Test
    fun `registry loads v2 presets from classpath and-or FS`() {
        // Use default loader (classpath /presets + optional -Dpreset.dir/PRESET_DIR)
        val reg = PresetRegistry.fromDefaultLocations()

        val list = runCatching { reg.listProfiles() }.getOrDefault(emptyList())
        assertTrue(list.isNotEmpty(), "Expected at least one preset to be discovered")

        // Spot-check a known key if present in your repo (adjust if needed)
        val maybe = reg.getProfile("GRA")
        assertNotNull(maybe, "GRA preset should be discoverable when bundled")
    }
}