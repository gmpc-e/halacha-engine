plugins {
    kotlin("jvm")
    application
}

repositories {
    mavenCentral()
}

dependencies {
    implementation(project(":core-engine"))
    implementation("junit:junit:4.12")
    implementation("org.junit.jupiter:junit-jupiter:5.8.1")

    val ktor = "3.0.1"
    implementation("io.ktor:ktor-server-core:$ktor")
    implementation("io.ktor:ktor-server-netty:$ktor")
    implementation("io.ktor:ktor-server-content-negotiation:$ktor")
    implementation("io.ktor:ktor-serialization-jackson:$ktor")
    implementation("io.ktor:ktor-server-status-pages:$ktor")
    implementation("com.kosherjava:zmanim:2.5.0")
    implementation("com.fasterxml.jackson.datatype:jackson-datatype-jsr310:2.17.2")
    implementation("ch.qos.logback:logback-classic:1.5.6")

    // Test Impl.

    testImplementation(kotlin("test"))
    testImplementation("org.junit.jupiter:junit-jupiter:5.10.3")

    // Ktor test kit (match your Ktor version)
    testImplementation("io.ktor:ktor-server-tests-jvm:2.3.11")
    testImplementation("io.ktor:ktor-server-content-negotiation:2.3.11")
    testImplementation("io.ktor:ktor-serialization-jackson:2.3.11")


}

application {
    mainClass.set("com.elad.halacha.rest.ServerKt")

}

tasks.test { useJUnitPlatform() }

kotlin {
    jvmToolchain(17)
}

