package com.elad.halachatime.core.engine

import com.elad.halachatime.core.engine.ZmanResolver
import com.elad.halachatime.core.model.Place
import com.elad.halachatime.core.model.ZmanRequest
import org.junit.jupiter.api.Assertions.*
import org.junit.jupiter.api.Test
import java.time.LocalDate

class ZmanResolverSmokeTest {
    @Test
    fun `compute returns core keys and methods`() {
        val date = LocalDate.of(2025, 9, 9)
        val place = Place("Test", 32.153, 34.893, 60.0, "Asia/Jerusalem")
        val res = ZmanResolver.compute(ZmanRequest(date, place, "GRA"))

        // Ensure a few central items exist
        val mm = res.methodMap.mapKeys { it.key.toString() }
        assertEquals("getSunrise", mm["NETZ"])
        assertEquals("getSunset", mm["SHKIA"])
        assertEquals("getSofZmanShmaGRA", mm["SHEMA_END"])
        assertEquals("getSofZmanTfilaGRA", mm["TEFILLAH_END"])

        // And they have times
        assertNotNull(res.results["NETZ"])
        assertNotNull(res.results["SHKIA"])
    }
}
