package com.elad.halachatime.core

import com.elad.halachatime.core.presets.PresetRegistry
import org.junit.jupiter.api.Assertions
import org.junit.jupiter.api.Test

class PresetSchemaAndLoadTest {

    @Test
    fun `all v2 presets validate and load with items`() {
        val registry = PresetRegistry.Companion.fromDefaultLocations()
        val profiles = registry.listProfiles()
        Assertions.assertTrue(
            profiles.isNotEmpty(),
            "No profiles discovered. Check -Dpreset.dir or resources/presets."
        )

        profiles.forEach { p ->
            Assertions.assertTrue(
                p.items.isNotEmpty(),
                "Profile ${p.key} loaded but has no items[]"
            )
            Assertions.assertFalse(p.key.isBlank(), "Profile key must not be blank")
            Assertions.assertFalse(p.displayName.isBlank(), "Profile displayName must not be blank")
        }

        // Spot-check presence of known boards
        val keys = profiles.map { it.key }.toSet()
        Assertions.assertTrue(keys.contains("GRA"), "GRA preset missing")
        Assertions.assertTrue(keys.contains("AHAVAT_SHALOM"), "AHAVAT_SHALOM preset missing")
    }
}