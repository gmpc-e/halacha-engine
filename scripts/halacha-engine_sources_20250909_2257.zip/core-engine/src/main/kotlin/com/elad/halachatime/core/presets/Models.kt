package com.elad.halachatime.core.presets

import com.fasterxml.jackson.annotation.JsonAlias

/* ---------- Legacy enums & types (kept for builtins) ---------- */
enum class SofZmanRef { GRA, MGA, BAAL_HA_TANYA, ATERET_TORAH, CUSTOM }
enum class OffsetType { FIXED_MINUTES, DEGREES, ZMANI_MINUTES, THREE_STARS, NONE }

data class OffsetMode(
    val type: OffsetType,
    val value: Double? = null
)

/* ---------- v2-capable BoardPreset (backwards compatible) ---------- */
data class BoardPreset(
    // v2 metadata (optional in builtins)
    val schemaVersion: String? = null,
    val key: String,
    val displayName: String,
    val dayModel: String? = null,

    // Accept both "items" (v2) and "zmanim" (older drafts)
    @JsonAlias("items", "zmanim")
    val items: List<BoardItem> = emptyList(),

    // Optional v2 extras
    val options: Map<String, Any?>? = null,
    val notes: Map<String, String>? = null,

    // ---- Legacy/builtin fields, kept nullable so JSON with only items still loads ----
    val sofZmanReference: SofZmanRef? = null,
    val alosMode: OffsetMode? = null,
    val tzeitMode: OffsetMode? = null,
    val misheyakirMinutes: Int? = null,
    val localeNotes: Map<String, String>? = null,
    val legacyNotes: String? = null
)

/* ---------- v2 Board item ---------- */
data class BoardItem(
    val id: String,
    val label: Map<String, String>? = null,
    val resolver: Map<String, Any?>? = null,
    val visible: Boolean? = null,
    val order: Int? = null,
    val kosherJavaMethod: String? = null,
    val notes: Map<String, String>? = null
)
