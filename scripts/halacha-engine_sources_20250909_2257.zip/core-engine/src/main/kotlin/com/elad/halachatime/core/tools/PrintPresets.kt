package com.elad.halachatime.core.presets

private fun OffsetMode?.pretty(): String =
    if (this == null) "—" else buildString {
        append(type.name)
        if (value != null) append("(", value, ")")
    }

private fun Map<String, String>?.prettyNotes(): String =
    if (this.isNullOrEmpty()) "—"
    else this.entries.joinToString(separator = " | ") { (k, v) -> "$k: $v" }

/**
 * Pretty-print a single BoardPreset in a way that tolerates null legacy fields
 * and shows v2 items when present.
 */
fun printPreset(p: BoardPreset): String = buildString {
    appendLine("key: ${p.key}")
    appendLine("name: ${p.displayName}")
    appendLine("schemaVersion: ${p.schemaVersion ?: "—"}")
    appendLine("dayModel: ${p.dayModel ?: "—"}")
    appendLine("sofZmanReference: ${p.sofZmanReference?.name ?: "—"}")
    appendLine("alosMode: ${p.alosMode.pretty()}")
    appendLine("tzeitMode: ${p.tzeitMode.pretty()}")
    appendLine("misheyakirMinutes: ${p.misheyakirMinutes ?: "—"}")
    appendLine("notes: ${p.notes.prettyNotes()}")
    if (!p.items.isNullOrEmpty()) {
        appendLine("items (${p.items.size}):")
        p.items.forEach { itm ->
            append("  - id="); append(itm.id)
            append(", visible="); append(itm.visible ?: true)
            append(", order="); append(itm.order ?: "—")
            appendLine()
            // labels
            val lblHe = itm.label?.get("he")
            val lblEn = itm.label?.get("en")
            appendLine("    label.he: ${lblHe ?: "—"}")
            appendLine("    label.en: ${lblEn ?: "—"}")
            // resolver echo (compact)
            when (val r = itm.resolver) {
                null -> appendLine("    resolver: —")
                else -> {
                    val type = (r["type"] as? String)?.uppercase() ?: "—"
                    appendLine("    resolver.type: $type")
                    when (type) {
                        "DEGREES" -> {
                            appendLine("    resolver.kind: ${(r["kind"] as? String) ?: "—"}")
                            appendLine("    resolver.degrees: ${(r["degrees"] ?: r["value"]) ?: "—"}")
                        }
                        "MINUTES" -> {
                            appendLine("    resolver.kind: ${(r["kind"] as? String) ?: "—"}")
                            appendLine("    resolver.minutes: ${(r["minutes"] ?: r["value"]) ?: "—"}")
                            appendLine("    resolver.baseline: ${(r["baseline"] as? String) ?: "—"}")
                        }
                        "FORMULA" -> {
                            appendLine("    resolver.name: ${(r["name"] ?: r["value"]) ?: "—"}")
                        }
                        else -> appendLine("    resolver.raw: $r")
                    }
                }
            }
            // method hint / notes
            appendLine("    kosherJavaMethod: ${itm.kosherJavaMethod ?: "—"}")
            appendLine("    notes: ${itm.notes?.entries?.joinToString { (k,v) -> "$k: $v" } ?: "—"}")
        }
    } else {
        appendLine("items: —")
    }
}

/** Pretty-print a list of presets (one after another). */
fun printPresets(list: List<BoardPreset>): String =
    list.joinToString(separator = "\n" + "-".repeat(60) + "\n") { printPreset(it) }
