package com.elad.halachatime.core.presets




import com.kosherjava.zmanim.ComplexZmanimCalendar
import com.elad.halachatime.core.presets.Resolver.*
import java.time.Instant
import java.time.ZoneId
import java.util.Date

class ProfileMethodMapper(
    private val czcFactory: (zoneId: ZoneId, lat: Double, lon: Double, elevationM: Double, y: Int, m: Int, d: Int) -> ComplexZmanimCalendar
) {

    fun evaluate(
        dateY: Int, dateM: Int, dateD: Int,
        lat: Double, lon: Double, elevationM: Double, tz: ZoneId,
        entries: List<Pair<String, Resolver>>
    ): Map<String, Instant?> {
        val czc = czcFactory(tz, lat, lon, elevationM, dateY, dateM, dateD)
        return entries.associate { (id, resolver) ->
            id to runCatching { resolveOne(czc, resolver) }.getOrNull()
        }
    }

    private fun Date?.toInstantOrNull(): Instant? = this?.toInstant()

    private fun resolveOne(czc: ComplexZmanimCalendar, r: Resolver): Instant? = when (r) {
        is Degrees -> when (r.method) {
            DegreeMethod.ALOS -> when (r.value) {
                16.1 -> czc.alos16Point1Degrees
                18.0 -> czc.alos18Degrees
                19.8 -> czc.alos19Point8Degrees
                else -> czc.getAlosByDegrees(r.value)
            }.toInstantOrNull()

            DegreeMethod.MISHEYAKIR -> when (r.value) {
                11.5 -> czc.misheyakir11Point5Degrees
                10.2 -> czc.misheyakir10Point2Degrees
                else -> czc.getMisheyakirByDegrees(r.value)
            }.toInstantOrNull()

            DegreeMethod.TZAIS_GEONIM -> when (r.value) {
                7.083 -> czc.tzaisGeonim7Point083Degrees
                8.5   -> czc.tzaisGeonim8Point5Degrees
                16.1  -> czc.tzais16Point1Degrees
                18.0  -> czc.tzais18Degrees
                26.0  -> czc.tzais26Degrees
                else  -> czc.getTzaisGeonimByDegrees(r.value)
            }.toInstantOrNull()
        }

        is Minutes -> when (r.mode) {
            MinutesMode.ALOS_BEFORE_SUNRISE_SEA -> {
                val sunriseSea = czc.seaLevelSunrise
                sunriseSea?.let { Date(it.time - r.minutes * 60_000L) }?.toInstant()
            }
            MinutesMode.TZAIS_AFTER_SUNSET_SEA -> {
                val sunsetSea = czc.seaLevelSunset
                sunsetSea?.let { Date(it.time + r.minutes * 60_000L) }?.toInstant()
            }
        }

        is Formula -> when (r.value) {
            "GRA_SHEMA"          -> czc.sofZmanShmaGRA.toInstantOrNull()
            "GRA_TEFILLA"        -> czc.sofZmanTfilaGRA.toInstantOrNull()
            "PLAG_GRA"           -> czc.plagHaminchaGRA.toInstantOrNull()
            "MGA_SHEMA_18D"      -> czc.sofZmanShmaMGA18Degrees.toInstantOrNull()
            "MGA_TEFILLA_18D"    -> czc.sofZmanTfilaMGA18Degrees.toInstantOrNull()
            "MGA_SHEMA_19P8D"    -> czc.sofZmanShmaMGA19Point8Degrees.toInstantOrNull()
            "MGA_TEFILLA_19P8D"  -> czc.sofZmanTfilaMGA19Point8Degrees.toInstantOrNull()
            "PLAG_MGA"           -> czc.plagHaminchaMGA.toInstantOrNull()
            else -> null // extend with Ateret Torah etc.
        }
    }
}
