package com.elad.halacha.rest

import com.elad.halachatime.core.engine.ShaotZmaniyot
import com.elad.halachatime.core.engine.ZmanIntrospector
import com.elad.halachatime.core.engine.ZmanResolver
import com.elad.halachatime.core.model.Place
import com.elad.halachatime.core.model.ZmanRequest
import com.elad.halachatime.core.presets.BoardPreset
import com.elad.halachatime.core.presets.PresetRegistry
import com.fasterxml.jackson.databind.SerializationFeature
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule
import com.kosherjava.zmanim.ComplexZmanimCalendar
import com.kosherjava.zmanim.util.GeoLocation
import io.ktor.http.*
import io.ktor.serialization.jackson.jackson
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.plugins.contentnegotiation.ContentNegotiation
import io.ktor.server.plugins.statuspages.StatusPages
import io.ktor.server.plugins.statuspages.exception
import io.ktor.server.response.*
import io.ktor.server.routing.*
import java.nio.file.Files
import java.nio.file.Path
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.*
import kotlin.reflect.KProperty1
import kotlin.reflect.full.declaredFunctions
import kotlin.reflect.full.memberProperties
import kotlin.reflect.jvm.isAccessible

fun main() {
    val port = System.getenv("PORT")?.toIntOrNull() ?: 8080
    val externalDirs = resolveExternalPresetDirs()
    val registry = if (externalDirs.isEmpty()) PresetRegistry.fromDefaultLocations() else PresetRegistry(externalDirs)

    embeddedServer(Netty, port = port) {
        install(StatusPages) {
            exception<Throwable> { call, cause ->
                call.respond(
                    HttpStatusCode.InternalServerError,
                    mapOf(
                        "error" to (cause.message ?: "internal error"),
                        "type" to (cause::class.simpleName ?: "Throwable")
                    )
                )
            }
        }
        install(ContentNegotiation) {
            jackson {
                registerModule(JavaTimeModule())
                disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
            }
        }

        routing {
            get("/health") { call.respond(mapOf("status" to "ok")) }

            // --- Profiles (tolerant) ---
            route("/profiles") {
                get {
                    val profiles: List<BoardPreset> = tryListProfiles(registry)
                    val payload = profiles.map { p -> mapOf("key" to p.key, "displayName" to p.displayName) }
                    call.respond(payload) // empty list if not discoverable
                }
                get("{key}") {
                    val key = call.parameters["key"].orEmpty()
                    val profile: BoardPreset? = getProfileCompat(registry, key)
                    if (profile == null) call.respond(HttpStatusCode.NotFound, mapOf("error" to "Profile '$key' not found"))
                    else call.respond(profile)
                }
            }

            // --- Zmanim (format=utc|local|both), versioned via ?scheme=v2 ---
            get("/zmanim") {
                val q = call.request.queryParameters
                val date = q["date"]?.let { LocalDate.parse(it) }
                    ?: return@get call.respond(HttpStatusCode.BadRequest, mapOf("error" to "date (yyyy-MM-dd) required"))

                // lat/lon optional (defaults to Jerusalem)
                val lat = q["lat"]?.toDoubleOrNull() ?: 31.778
                val lon = q["lon"]?.toDoubleOrNull() ?: 35.235
                val elev = q["elev"]?.toDoubleOrNull() ?: 800.0
                val tzId = q["tz"] ?: "Asia/Jerusalem"

                val presetKey = q["preset"] ?: "GRA"
                val format = (q["format"] ?: "both").lowercase()
                val scheme = (q["scheme"] ?: "").lowercase()
                val explain = q["explain"]?.toBoolean() ?: false
                val place = Place(q["name"] ?: "Custom", lat, lon, elev, tzId)

                // Compute legacy engine output (canonical IDs) for fallback/compat
                val legacy = ZmanResolver.compute(ZmanRequest(date, place, presetKey))

                // ---- V2 payload (preset-driven when available) ----
                if (scheme == "v2") {
                    val preset: BoardPreset? = getProfileCompat(registry, presetKey) // may be null
                    val items: List<ZmanItemV2> = buildItemsV2(preset, legacy, explain)

                    val shaped = when (format) {
                        "utc" -> items.map { it.copy(local = null) }
                        "local" -> items.map { it.copy(utc = null) }
                        else -> items
                    }

                    val payload = ZmanimResponseV2(
                        schemeVersion = "v2",
                        profileKey = presetKey, // echo requested key even if preset not found
                        meta = ZmanMeta(
                            date = date.toString(),
                            lat = lat, lon = lon, elevationM = elev, tz = tzId
                        ),
                        items = shaped
                    )
                    return@get call.respond(payload)
                }

                // ---- legacy/default payload (unchanged) ----
                val payload: Any = when (format) {
                    "utc" -> mapOf(
                        "preset" to legacy.preset, "place" to legacy.place, "date" to legacy.date,
                        "results" to legacy.results, "methodMap" to legacy.methodMap, "meta" to legacy.meta
                    )
                    "local" -> mapOf(
                        "preset" to legacy.preset, "place" to legacy.place, "date" to legacy.date,
                        "resultsLocal" to legacy.resultsLocal, "methodMap" to legacy.methodMap, "meta" to legacy.meta
                    )
                    else -> legacy
                }
                call.respond(payload)
            }

            // --- All CZC methods (format=utc|local|both) ---
            get("/zmanim/all-methods") {
                val q = call.request.queryParameters
                val date = q["date"]?.let { LocalDate.parse(it) }
                    ?: return@get call.respond(HttpStatusCode.BadRequest, mapOf("error" to "date (yyyy-MM-dd) required"))

                // lat/lon optional (defaults to Jerusalem)
                val lat = q["lat"]?.toDoubleOrNull() ?: 31.778
                val lon = q["lon"]?.toDoubleOrNull() ?: 35.235
                val elev = q["elev"]?.toDoubleOrNull() ?: 800.0
                val tzId = q["tz"] ?: "Asia/Jerusalem"
                val name = q["name"] ?: "Custom"
                val format = (q["format"] ?: "both").lowercase()

                val place = Place(name, lat, lon, elev, tzId)
                val raw = ZmanIntrospector.computeAll(date, place) // Map<Any, Date?>

                val zoneId = ZoneId.of(tzId)
                val fmt = DateTimeFormatter.ISO_OFFSET_DATE_TIME
                val utcMap = raw.mapKeys { (k, _) -> k.toString() }.mapValues { (_, d) -> d?.toInstant()?.toString() }
                val localMap = raw.mapKeys { (k, _) -> k.toString() }.mapValues { (_, d) -> d?.toInstant()?.atZone(zoneId)?.format(fmt) }

                val payload = when (format) {
                    "utc" -> mapOf(
                        "date" to date.toString(),
                        "place" to mapOf("name" to name, "lat" to lat, "lon" to lon, "elevationMeters" to elev, "timeZoneId" to tzId),
                        "count" to utcMap.size,
                        "methods" to utcMap,
                        "meta" to mapOf("format" to "utc", "engine" to "ComplexZmanimCalendar")
                    )
                    "local" -> mapOf(
                        "date" to date.toString(),
                        "place" to mapOf("name" to name, "lat" to lat, "lon" to lon, "elevationMeters" to elev, "timeZoneId" to tzId),
                        "count" to localMap.size,
                        "methods" to localMap,
                        "meta" to mapOf("format" to "local", "engine" to "ComplexZmanimCalendar")
                    )
                    else -> mapOf(
                        "date" to date.toString(),
                        "place" to mapOf("name" to name, "lat" to lat, "lon" to lon, "elevationMeters" to elev, "timeZoneId" to tzId),
                        "count" to localMap.size,
                        "methodsUtc" to utcMap,
                        "methodsLocal" to localMap,
                        "meta" to mapOf("format" to "both", "engine" to "ComplexZmanimCalendar")
                    )
                }
                call.respond(payload)
            }

            get("/debug/presets") {
                val fromEnv = System.getenv("PRESET_DIR")
                val fromProp = System.getProperty("preset.dir")
                val dir = fromProp ?: fromEnv
                val files = dir?.let { java.io.File(it).listFiles { f -> f.isFile && f.name.endsWith(".json") } }?.map { it.name } ?: emptyList()
                // Try to list profiles via reflection; if it throws, return the error
                val registryInfo = runCatching {
                    val reg = if (dir.isNullOrBlank()) PresetRegistry.fromDefaultLocations() else PresetRegistry(listOf(java.nio.file.Path.of(dir)))
                    val method = PresetRegistry::class.declaredFunctions.firstOrNull { it.name in setOf("listProfiles","list","all") && it.parameters.size == 1 }
                    method?.isAccessible = true
                    val listed = method?.call(reg) as? List<BoardPreset> ?: emptyList()
                    mapOf("count" to listed.size, "keys" to listed.map { it.key })
                }.fold(onSuccess = { it }, onFailure = { ex ->
                    mapOf("error" to (ex.message ?: ex::class.simpleName.orEmpty()))
                })
                call.respond(
                    mapOf(
                        "env_PRESET_DIR" to fromEnv,
                        "prop_preset.dir" to fromProp,
                        "dirExists" to (dir?.let { java.io.File(it).exists() } ?: false),
                        "jsonFiles" to files,
                        "registry" to registryInfo
                    )
                )
            }

            // --- Sha'ot/Dakot Zmaniyot ---
            get("/zmanim/shaot") {
                val q = call.request.queryParameters
                val date = q["date"]?.let { LocalDate.parse(it) }
                    ?: return@get call.respond(HttpStatusCode.BadRequest, mapOf("error" to "date (yyyy-MM-dd) required"))

                // lat/lon optional (defaults to Jerusalem)
                val lat = q["lat"]?.toDoubleOrNull() ?: 31.778
                val lon = q["lon"]?.toDoubleOrNull() ?: 35.235
                val elev = q["elev"]?.toDoubleOrNull() ?: 800.0
                val tzId = q["tz"] ?: "Asia/Jerusalem"
                val alosDeg = q["alosDeg"]?.toDoubleOrNull() ?: 16.1
                val tzaisDeg = q["tzaisDeg"]?.toDoubleOrNull() ?: 8.5
                val name = q["name"] ?: "Custom"

                val place = Place(name, lat, lon, elev, tzId)
                val gra = ShaotZmaniyot.compute(date, place, ShaotZmaniyot.Mode.GRA)
                val mga = ShaotZmaniyot.compute(date, place, ShaotZmaniyot.Mode.MGA, alosDeg, tzaisDeg)

                fun pretty(ms: Long) = if (ms <= 0) null else {
                    val minutes = ms / 60000.0
                    mapOf(
                        "millis" to ms,
                        "minutes" to "%.3f".format(minutes),
                        "hh:mm:ss" to String.format(
                            "%02d:%02d:%02d",
                            (ms / 3600000),
                            (ms % 3600000) / 60000,
                            (ms % 60000) / 1000
                        )
                    )
                }

                call.respond(
                    mapOf(
                        "date" to date.toString(),
                        "place" to mapOf("name" to name, "lat" to lat, "lon" to lon, "elevationMeters" to elev, "timeZoneId" to tzId),
                        "GRA" to mapOf("shaahZmanit" to pretty(gra.shaahMillis), "dakaZmanit" to pretty(gra.dakaMillis), "meta" to gra.meta),
                        "MGA" to mapOf("shaahZmanit" to pretty(mga.shaahMillis), "dakaZmanit" to pretty(mga.dakaMillis), "meta" to (mga.meta + mapOf("alosDeg" to alosDeg, "tzaisDeg" to tzaisDeg)))
                    )
                )
            }
        }
    }.start(wait = true)
}

/* ---------- V2 response models ---------- */

data class ZmanimResponseV2(
    val schemeVersion: String,
    val profileKey: String,
    val meta: ZmanMeta,
    val items: List<ZmanItemV2>
)

data class ZmanMeta(
    val date: String,
    val lat: Double,
    val lon: Double,
    val elevationM: Double,
    val tz: String
)

data class ZmanItemV2(
    val id: String,
    val label: Map<String, String>?,
    val utc: String?,
    val local: String?,
    val resolver: Any? = null,          // echoed only when explain=true (preset resolver object)
    val kosherJavaMethod: String? = null // echoed only when explain=true (preset or resolved methodMap)
)

/* ---------- Helpers ---------- */

private fun resolveExternalPresetDirs(): List<Path> {
    val fromEnv = System.getenv("PRESET_DIR")?.takeIf { it.isNotBlank() }?.let { Path.of(it) }
    val fromProp = System.getProperty("preset.dir")?.takeIf { it.isNotBlank() }?.let { Path.of(it) }
    return listOfNotNull(fromEnv, fromProp).filter { Files.exists(it) }
}

// Return [] instead of throwing if registry does not have a list method
private fun tryListProfiles(registry: PresetRegistry): List<BoardPreset> {
    val f = PresetRegistry::class.declaredFunctions.firstOrNull {
        it.name in setOf("listProfiles", "list", "all") && it.parameters.size == 1
    } ?: return emptyList()
    f.isAccessible = true
    @Suppress("UNCHECKED_CAST")
    return runCatching { f.call(registry) as List<BoardPreset> }.getOrElse { emptyList() }
}

private fun getProfileCompat(registry: PresetRegistry, key: String): BoardPreset? {
    val f = PresetRegistry::class.declaredFunctions.firstOrNull {
        it.name in setOf("getProfile", "get") && it.parameters.size == 2
    } ?: return null
    f.isAccessible = true
    @Suppress("UNCHECKED_CAST")
    return runCatching { f.call(registry, key) as BoardPreset? }.getOrNull()
}

/* ============================================================
   V2 preset-driven builder (no canonical collapsing)
   ============================================================ */

// Build v2 items using preset.items[*] (or .zmanim[*]) if present; else fall back to engine maps.
private fun buildItemsV2(
    preset: BoardPreset?,   // may be null
    res: Any,               // ZmanResults (legacy engine output)
    explain: Boolean
): List<ZmanItemV2> {
    // Legacy maps for fallback
    val results      = toStringKeyed(getMapAny(res, "results"))
    val resultsLocal = toStringKeyed(getMapAny(res, "resultsLocal"))
    val methodMap    = toStringKeyed(getMapAny(res, "methodMap"))

    // Try board collections: v2 uses "items", older drafts "zmanim"
    val presetItems = preset?.let { getList(it, "items") ?: getList(it, "zmanim") }

    // If no preset, fall back to canonical output (legacy behavior)
    if (presetItems == null) {
        val ids = (results.keys + resultsLocal.keys + methodMap.keys).toSortedSet()
        return ids.map { id ->
            val utc   = results[id]?.toString()
            val local = resultsLocal[id]?.toString()
            val kj    = if (explain) methodMap[id]?.toString() else null
            ZmanItemV2(id = id, label = null, utc = utc, local = local, resolver = null, kosherJavaMethod = kj)
        }
    }

    // --- PRESET PATH: compute each resolver verbatim ---
    val dateStr = getString(res, "date") ?: error("Missing date in results")
    val place   = getAny(res, "place") ?: error("Missing place in results")
    val tzId    = getString(place, "timeZoneId") ?: "Asia/Jerusalem"
    val zoneId  = ZoneId.of(tzId)
    val fmt     = DateTimeFormatter.ISO_OFFSET_DATE_TIME

    val name = getString(place, "name") ?: "Custom"
    val lat  = getDouble(place, "latitude") ?: 31.778
    val lon  = getDouble(place, "longitude") ?: 35.235
    val elev = getDouble(place, "elevationMeters") ?: 800.0

    val czc = buildCZC(LocalDate.parse(dateStr), name, lat, lon, elev, tzId)

    // Preserve author order when "order" exists
    val sorted = presetItems.sortedBy { (getInt(it, "order") ?: Int.MAX_VALUE) }

    return sorted.map { z ->
        val id      = getString(z, "id") ?: ""
        val label   = getMap(z, "label") as? Map<String, String>
        val rez     = getAny(z, "resolver")
        val kjHint  = getString(z, "kosherJavaMethod")

        val computed = computeWithResolver(czc, rez)
        val utc = computed?.first?.toInstant()?.toString()
        val local = computed?.first?.toInstant()?.atZone(zoneId)?.format(fmt)
        val kj = if (explain) (computed?.second ?: kjHint) else null

        ZmanItemV2(
            id = id,
            label = label,
            utc = utc,
            local = local,
            resolver = if (explain) rez else null,
            kosherJavaMethod = kj
        )
    }
}

/* ---------- CZC builder & resolver mapping ---------- */

private fun buildCZC(date: LocalDate, name: String, lat: Double, lon: Double, elev: Double, tzId: String): ComplexZmanimCalendar {
    val tz: TimeZone = TimeZone.getTimeZone(ZoneId.of(tzId))
    val gl = GeoLocation(name, lat, lon, elev, tz)
    val czc = ComplexZmanimCalendar(gl)
    val cal = GregorianCalendar(tz).apply {
        set(date.year, date.monthValue - 1, date.dayOfMonth, 12, 0, 0) // noon to avoid DST edges
        set(Calendar.MILLISECOND, 0)
    }
    czc.calendar = cal
    return czc
}

/**
 * Returns Pair<Date?, String?> where second is a kosherJavaMethod hint if known.
 * `resolver` is a POJO/Map-like with fields:
 *  - type: "DEGREES" | "MINUTES" | "FORMULA"
 *  - For DEGREES: kind: "ALOS"|"MISHEYAKIR"|"TZAIS", degrees: Double
 *  - For MINUTES: kind: "ALOS"|"TZAIS", minutes: Int, baseline: "SEA_LEVEL_SUNRISE"|"SEA_LEVEL_SUNSET"
 *  - For FORMULA: name: one of allowed formulas (GRA_SHEMA, MGA_SHEMA, ... SUNSET_VISIBLE)
 */
private fun computeWithResolver(
    czc: ComplexZmanimCalendar,
    resolver: Any?
): Pair<Date?, String?>? {
    if (resolver == null) return null
    val type = getString(resolver, "type")?.uppercase(Locale.ROOT) ?: return null
    return when (type) {
        "DEGREES" -> {
            val kind = getString(resolver, "kind")?.uppercase(Locale.ROOT) ?: return null
            val deg  = (getDouble(resolver, "degrees") ?: getDouble(resolver, "value")) ?: return null
            when (kind) {
                "ALOS" -> when (deg) {
                    16.1 -> Pair(czc.alos16Point1Degrees, "getAlos16Point1Degrees")
                    else -> Pair(czc.getSunriseOffsetByDegrees(-deg), "getSunriseOffsetByDegrees(${-deg})")
                }
                "MISHEYAKIR" -> when (deg) {
                    11.5 -> Pair(czc.misheyakir11Point5Degrees, "getMisheyakir11Point5Degrees")
                    10.2 -> Pair(czc.misheyakir10Point2Degrees, "getMisheyakir10Point2Degrees")
                    else -> Pair(czc.getSunriseOffsetByDegrees(-deg), "getSunriseOffsetByDegrees(${-deg})")
                }
                "TZAIS" -> when (deg) {
                    4.8   -> Pair(czc.tzaisGeonim4Point8Degrees, "getTzaisGeonim4Point8Degrees")
                    6.45  -> Pair(czc.tzaisGeonim6Point45Degrees, "getTzaisGeonim6Point45Degrees")
                    7.083 -> Pair(czc.tzaisGeonim7Point083Degrees, "getTzaisGeonim7Point083Degrees")
                    8.5   -> Pair(czc.tzaisGeonim8Point5Degrees, "getTzaisGeonim8Point5Degrees")
                    16.1  -> Pair(czc.tzais16Point1Degrees, "getTzais16Point1Degrees")
                    18.0  -> Pair(czc.tzais18Degrees, "getTzais18Degrees")
                    else  -> Pair(czc.getSunsetOffsetByDegrees(deg), "getSunsetOffsetByDegrees($deg)")
                }
                else -> null
            }
        }
        "MINUTES" -> {
            val kind = getString(resolver, "kind")?.uppercase(Locale.ROOT) ?: return null
            val minutes = (getInt(resolver, "minutes") ?: getInt(resolver, "value")) ?: return null
            val baseline = getString(resolver, "baseline")?.uppercase(Locale.ROOT)
                ?: if (kind == "TZAIS") "SEA_LEVEL_SUNSET" else "SEA_LEVEL_SUNRISE"
            val base: Date? = when (baseline) {
                "SEA_LEVEL_SUNRISE" -> czc.seaLevelSunrise
                "SEA_LEVEL_SUNSET"  -> czc.seaLevelSunset
                else -> czc.seaLevelSunset
            }
            val d = base?.let { Date(it.time + minutes * 60_000L) }
            val hint = when {
                kind == "TZAIS" && minutes == 72 && baseline == "SEA_LEVEL_SUNSET" -> "getTzais72"
                else -> "baseline+$minutes"
            }
            Pair(d, hint)
        }
        "FORMULA" -> {
            val name = (getString(resolver, "name") ?: getString(resolver, "value"))?.uppercase(Locale.ROOT) ?: return null
            when (name) {
                "GRA_SHEMA"         -> Pair(czc.sofZmanShmaGRA, "getSofZmanShmaGRA")
                "MGA_SHEMA"         -> Pair(czc.sofZmanShmaMGA, "getSofZmanShmaMGA")
                "MGA_SHEMA_19P8D"   -> Pair(czc.sofZmanShmaMGA19Point8Degrees, "getSofZmanShmaMGA19Point8Degrees")
                "GRA_TEFILLA"       -> Pair(czc.sofZmanTfilaGRA, "getSofZmanTfilaGRA")
                "MGA_TEFILLA_19P8D" -> Pair(czc.sofZmanTfilaMGA19Point8Degrees, "getSofZmanTfilaMGA19Point8Degrees")
                "CHATZOS"           -> Pair(czc.chatzos, "getChatzos")
                "MINCHA_GEDOLA_30M" -> Pair(czc.minchaGedola30Minutes, "getMinchaGedola30Minutes")
                "MINCHA_KETANA_GRA" -> Pair(czc.minchaKetana, "getMinchaKetana")
                "PLAG_GRA"          -> Pair(czc.plagHamincha, "getPlagHamincha")
                "SUNRISE_SEA"       -> Pair(czc.seaLevelSunrise, "getSeaLevelSunrise")
                "SUNRISE_VISIBLE"   -> Pair(czc.sunrise,        "getSunrise")        // elevation-adjusted (visible proxy)
                "SUNSET_SEA"        -> Pair(czc.seaLevelSunset, "getSeaLevelSunset")
                "SUNSET_VISIBLE"    -> Pair(czc.sunset,         "getSunset")         // elevation-adjusted (visible proxy)

                else -> null
            }
        }
        else -> null
    }
}

/* ---------- Reflection utilities used above ---------- */

private fun getAny(instance: Any, name: String): Any? =
    instance::class.memberProperties.firstOrNull { it.name == name }?.let { (it as KProperty1<Any, *>).get(instance) }

private fun getString(instance: Any, name: String): String? = (getAny(instance, name) as? String)

private fun getInt(instance: Any, name: String): Int? =
    when (val v = getAny(instance, name)) {
        is Int -> v
        is Number -> v.toInt()
        is String -> v.toIntOrNull()
        else -> null
    }

private fun getDouble(instance: Any, name: String): Double? =
    when (val v = getAny(instance, name)) {
        is Double -> v
        is Float -> v.toDouble()
        is Number -> v.toDouble()
        is String -> v.toDoubleOrNull()
        else -> null
    }

@Suppress("UNCHECKED_CAST")
private fun getMap(instance: Any, name: String): Map<String, Any?> =
    (getAny(instance, name) as? Map<String, Any?>) ?: emptyMap()

@Suppress("UNCHECKED_CAST")
private fun getList(instance: Any, name: String): List<Any>? =
    getAny(instance, name) as? List<Any>

@Suppress("UNCHECKED_CAST")
private fun getMapAny(instance: Any, name: String): Map<Any?, Any?> =
    (getAny(instance, name) as? Map<Any?, Any?>) ?: emptyMap()

private fun toStringKeyed(src: Map<Any?, Any?>): Map<String, Any?> =
    if (src.isEmpty()) emptyMap()
    else buildMap(src.size) {
        for ((k, v) in src) put(k?.toString() ?: "null", v)
    }
