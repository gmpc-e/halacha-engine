package com.elad.halachatime.core.tools

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import java.nio.file.Files
import java.nio.file.Path
import java.time.LocalDate

/**
 * Generate Markdown stubs for v2 preset JSONs (Task #5).
 * Input:  core-engine/src/main/resources/presets/*.json
 * Output: docs/presets/<KEY>.md
 */
object GeneratePresetDocs {
  @JvmStatic
  fun main(args: Array<String>) {
    val mapper = jacksonObjectMapper().findAndRegisterModules()
    val inDir = Path.of("core-engine/src/main/resources/presets")
    val outDir = Path.of("docs/presets")
    Files.createDirectories(outDir)

    Files.list(inDir).use { stream ->
      stream.filter { it.toString().endsWith(".json") }.forEach { p ->
        val root: JsonNode = mapper.readTree(Files.readString(p))
        val key = root.get("key").asText()
        val title = root.get("displayName")?.asText() ?: key
        val dayModel = root.get("dayModel")?.asText() ?: ""
        val zmanim = root.get("zmanim")

        val sb = StringBuilder()
        sb.appendLine("# $title ($key)")
        sb.appendLine()
        sb.appendLine("_Auto-generated stub • ${LocalDate.now()}_")
        sb.appendLine()
        if (dayModel.isNotBlank()) sb.appendLine("**Day model:** `$dayModel`  ")
        sb.appendLine("**Zmanim count:** ${zmanim?.size() ?: 0}")
        sb.appendLine()
        sb.appendLine("## Mapping")
        sb.appendLine("| Zman | Label | Resolver | CZC Method | Notes |")
        sb.appendLine("|---|---|---|---|---|")

        if (zmanim != null && zmanim.isArray) {
          val items = zmanim.toList().sortedBy { it.get("order")?.asInt() ?: 0 }
          for (z in items) {
            val id = z.get("id")?.asText() ?: ""
            val labelNode = z.get("label")
            val label = when {
              labelNode?.get("en") != null -> labelNode.get("en").asText()
              labelNode?.get("he") != null -> labelNode.get("he").asText()
              else -> id
            }
            val resolver = z.get("resolver")
            val resolverStr = resolver?.toString() ?: ""
            val czc = z.get("kosherJavaMethod")?.asText() ?: ""
            val notes = z.get("notes")?.get("en")?.asText() ?: z.get("notes")?.get("he")?.asText() ?: ""
            sb.appendLine("| `$id` | $label | `${resolverStr}` | `${czc}` | ${notes} |")
          }
        }

        val options = root.get("options")
        if (options != null) {
          sb.appendLine()
          sb.appendLine("## Options")
          sb.appendLine("```json")
          sb.appendLine(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(options))
          sb.appendLine("```")
        }

        Files.writeString(outDir.resolve("$key.md"), sb.toString())
      }
    }
  }
}
