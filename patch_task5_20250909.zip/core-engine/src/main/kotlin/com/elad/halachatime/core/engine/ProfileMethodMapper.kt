package com.elad.halachatime.core.engine

import com.kosherjava.zmanim.ComplexZmanimCalendar
import com.elad.halachatime.core.presets.Resolver
import com.elad.halachatime.core.presets.Resolver.*
import java.time.Instant
import java.time.ZoneId
import java.util.*
import kotlin.math.abs

/**
 * Maps profile resolvers (DEGREES / MINUTES / FORMULA) to concrete ComplexZmanimCalendar calls.
 * This is used by profile-aware computation in Task #5.
 */
class ProfileMethodMapper(
    private val czcFactory: (zoneId: ZoneId, lat: Double, lon: Double, elevationM: Double, y: Int, m: Int, d: Int) -> ComplexZmanimCalendar
) {

    fun evaluate(
        dateY: Int, dateM: Int, dateD: Int,
        lat: Double, lon: Double, elevationM: Double, tz: ZoneId,
        entries: List<Pair<String, Resolver>>
    ): Map<String, Instant?> {
        val czc = czcFactory(tz, lat, lon, elevationM, dateY, dateM, dateD)
        return entries.associate { (id, r) -> id to runCatching { resolveOne(czc, r) }.getOrNull() }
    }

    private fun Date?.toInstantOrNull(): Instant? = this?.toInstant()

    private fun resolveOne(czc: ComplexZmanimCalendar, r: Resolver): Instant? = when (r) {
        is Degrees -> when (r.method) {
            DegreeMethod.ALOS -> alosByDegrees(czc, r.value)?.toInstantOrNull()
            DegreeMethod.MISHEYAKIR -> misheyakirByDegrees(czc, r.value)?.toInstantOrNull()
            DegreeMethod.TZAIS_GEONIM -> tzaisByDegrees(czc, r.value)?.toInstantOrNull()
        }
        is Minutes -> when (r.mode) {
            MinutesMode.ALOS_BEFORE_SUNRISE_SEA -> {
                val sunriseSea = czc.seaLevelSunrise ?: return null
                Date(sunriseSea.time - r.minutes * 60_000L).toInstant()
            }
            MinutesMode.TZAIS_AFTER_SUNSET_SEA -> {
                val sunsetSea = czc.seaLevelSunset ?: return null
                Date(sunsetSea.time + r.minutes * 60_000L).toInstant()
            }
        }
        is Formula -> when (r.value) {
            // GRA flavors
            "GRA_SHEMA"         -> czc.sofZmanShmaGRA.toInstantOrNull()
            "GRA_TEFILLA"       -> czc.sofZmanTfilaGRA.toInstantOrNull()
            "PLAG_GRA"          -> czc.plagHaminchaGRA.toInstantOrNull()
            // MGA flavors
            "MGA_SHEMA_18D"     -> czc.sofZmanShmaMGA18Degrees.toInstantOrNull()
            "MGA_TEFILLA_18D"   -> czc.sofZmanTfilaMGA18Degrees.toInstantOrNull()
            "MGA_SHEMA_19P8D"   -> czc.sofZmanShmaMGA19Point8Degrees.toInstantOrNull()
            "MGA_TEFILLA_19P8D" -> czc.sofZmanTfilaMGA19Point8Degrees.toInstantOrNull()
            "PLAG_MGA"          -> czc.plagHaminchaMGA.toInstantOrNull()
            else -> null // extend as needed (Ateret Torah, Igrot Moshe fixed chatzos variants, etc.)
        }
    }

    // ---- Helpers for degree mapping (choose exact or nearest supported) ----

    private fun <T> whenClosest(
        target: Double,
        vararg options: Pair<Double, () -> T?>,
        eps: Double = 1e-3
    ): T? {
        options.forEach { (deg, f) -> if (kotlin.math.abs(target - deg) <= eps) return f() }
        val best = options.minByOrNull { (deg, _) -> abs(target - deg) } ?: return null
        return best.second()
    }

    private fun alosByDegrees(czc: ComplexZmanimCalendar, deg: Double) = whenClosest(deg,
        16.1 to { czc.alos16Point1Degrees },
        18.0 to { czc.alos18Degrees },
        19.8 to { czc.alos19Point8Degrees },
        26.0 to { czc.alos26Degrees },
    )

    private fun misheyakirByDegrees(czc: ComplexZmanimCalendar, deg: Double) = whenClosest(deg,
        11.5 to { czc.misheyakir11Point5Degrees },
        10.2 to { czc.misheyakir10Point2Degrees },
    )

    private fun tzaisByDegrees(czc: ComplexZmanimCalendar, deg: Double) = whenClosest(deg,
        7.083 to { czc.tzaisGeonim7Point083Degrees },
        8.5   to { czc.tzaisGeonim8Point5Degrees },
        16.1  to { czc.tzais16Point1Degrees },
        18.0  to { czc.tzais18Degrees },
        19.8  to { czc.tzais19Point8Degrees },
        26.0  to { czc.tzais26Degrees },
    )
}
